#! /bin/bash

if [ -z "$EUID" ] && [ $(id -u) -ne 0 ]; then
  echo "You must be logged in as root or sudo to install!"
  exit 1
elif [ ! -z "$EUID" ] && [ $EUID -ne 0 ]; then
  echo "You must be logged in as root or sudo to install!"
  exit 1
fi

if [ "$1" = "-h" ]; then
   echo "Use is $0 [<install path>]"
   exit 0
fi

DESTDIR=/usr/local/deviceauthority/

if [ $# -lt 1 ]; then
   echo "No install path specified on command line, using default path $DESTDIR."
else
   DESTDIR="$1"
fi

test -d "${DESTDIR}." || mkdir -p "${DESTDIR}."

# Test DESTDIR is writable and exit if not
if [ ! -w $DESTDIR ]; then
  echo "You must have write permission for $DESTDIR"
  exit 1
fi

ostype=$OSTYPE
if [ -z "$ostype" ]; then
  ostype=$(uname | tr "[:upper:]" "[:lower:]")
fi

case $ostype in
  linux*)
    echo "Installing on Linux"
    ;;
  darwin*)
    echo "Installing on OS X"
    ;;
  *)
    # Unsupported platform, default to windows
    echo "Unsupported OS!"
    exit 1
esac

echo "Installing to $DESTDIR"

arch=''
distro=''

if [ -z "$distro" ]; then
  ## Distro is not given, let's auto detect it
    which lsb_release > /dev/null
    rc=$?
    if [ $rc -eq 0 ]; then
      # Ubuntu distro (most likely)
      distro=`lsb_release -i | awk -F':' '{print $2}' | sed -e 's/^[[:space:]]*//' | awk '{print tolower($1)}'`
    else
      redhatrelfile=/etc/redhat-release
       if [ -f $redhatrelfile ]; then
          if [ $(grep 'CentOS' $redhatrelfile | wc -l) -gt 0 ]; then
            ## CentOS distro
            distro=$(cat $redhatrelfile | awk '{print tolower($1)}')
	    if [ ! -f /usr/lib64/libhal.so.1 ]; then
             echo "You need to have hal installed first for centos version < 6.8"
            fi
	     echo "Agent functionality has been verified by DA on $distro-6.5"
          elif [ $(grep 'Red Hat Enterprise' $redhatrelfile | wc -l) -gt 0 ]; then
            ## RedHat distro
            distro="rhel"
	    if [ ! -f /usr/lib64/libhal.so.1 ]; then
             echo "You need to have hal installed first."
            fi
	     echo "Agent functionality has been verified by DA on $distro versions"
          elif [ $(grep 'Fedora' $redhatrelfile | wc -l) -gt 0 ]; then
            ## Fedora distro
            distro=$(cat $redhatrelfile | awk '{print tolower($1)}')
	    echo "Agent functionality has been verified by DA on $distro-22 "
          else
            echo "Unsupported Linux distro $redhatrelfile. Bails out!"; exit 1
	  fi
       else
          osrelease=/etc/os-release
          unameVal=`uname -a`
          if [ -f $osrelease ]; then
             if [ $(grep 'PRETTY_NAME' $osrelease | grep 'Wind River' | wc -l) -gt 0 ]; then
               ## Windriver distro
                distro='wrlinux'
                echo "Agent functionality has been verified by DA on $distro 7.0.0.8"
             fi
	  elif [ $(echo $unameVal|grep 'armv5' | wc -l) -gt 0 ] || [ $(echo $unameVal|grep 'armv7' | wc -l) -gt 0 ]; then
                echo "Agent functionality has been verified by DA on ARMv5 multitech conduit"
	  elif [ $(echo $unameVal|grep 'mips' | wc -l) -gt 0 ]; then
                echo "Agent functionality has been verified by DA on mips"
          else
                echo "Unsupported Linux platform. Bails out!"; exit 1
          fi
        fi
    fi #end of which lsb_release
fi

if [ -z "$arch" ]; then
  # ARCH is not given, let' auto detect it
  arch=$(uname -p)
  if [ "$arch" = "unknown" ]; then
    arch=$(uname -i)
    if [ "$arch" = "unknown" ]; then
      arch=$(uname -m)
    fi
  fi
fi

echo "Distro: ${distro}"
echo "ARCH: ${arch}"

if [ $(echo $arch|grep 'armv5' | wc -l) -gt 0 ] || [ $(echo $arch|grep 'mips' | wc -l) -gt 0 ] || [ $(echo $arch|grep 'x86_64' | wc -l) -gt 0 ] || [ $(echo $arch|grep 'armv7' | wc -l) -gt 0 ]; then
    echo "$arch is verified."
else
 case $distro in
  rhel|fedora|ubuntu|wrlinux|centos)
    ;;
  *)
    echo "ERR: Unsupported linux platform ${distro}."
    exit 1
    ;;
 esac
 case $arch in
  x86_64)
    ;;
  *)
    echo "ERR: Unsupported architecture ${arch}. 64-bits architecture required."
    exit 1
    ;;
 esac
fi

test -d "${DESTDIR}./sbin" || mkdir -p "${DESTDIR}./sbin"
test ! -f "${DESTDIR}./sbin/credential_manager" || mv "${DESTDIR}./sbin/credential_manager" "${DESTDIR}./sbin/credential_manager.old"
cp credential_manager "${DESTDIR}./sbin/credential_manager"
cp startCredentialManager.sh "${DESTDIR}./sbin/"


test -d "${DESTDIR}./conf" || mkdir -p "${DESTDIR}./conf"
test ! -f "${DESTDIR}./conf/credentialmanager.conf" || mv "${DESTDIR}./conf/credentialmanager.conf" "${DESTDIR}./conf/credentialmanager.conf.old"
cp credentialmanager.conf "${DESTDIR}./conf/credentialmanager.conf"

test -d "${DESTDIR}./logs" || mkdir -p "${DESTDIR}./logs"
test -d "${DESTDIR}./lib" || mkdir -p "${DESTDIR}./lib"

# Preparing dependencies
copyLib()
{
  EXE=credential_manager
  result=$(LD_LIBRARY_PATH=${DESTDIR}/lib ./$EXE credentialmanager.conf 2>&1)
  if [ $(echo $result|grep 'libssl' | wc -l) -gt 0 ]||
     [ $(echo $result|grep 'libcrypto' | wc -l) -gt 0 ]||
     [ $(echo $result|grep 'libnaudaddk_shared.so' | wc -l) -gt 0 ]||
     [ $(echo $result|grep 'libcurl' | wc -l) -gt 0 ]||
     [ $(echo $result|grep 'libz' | wc -l) -gt 0 ]; then
      if [ -e lib/libcurl.so.4.4.0 ];then
        cp lib/libcurl.so.4.4.0 ${DESTDIR}./lib/
        ln -sf ${DESTDIR}./lib/libcurl.so.4.4.0 ${DESTDIR}./lib/libcurl.so.4
      fi
      if [ -e lib/libcrypto.so.1.0.0 ];then
        cp lib/libcrypto.so.1.0.0 ${DESTDIR}./lib
        ln -sf ${DESTDIR}./lib/libcrypto.so.1.0.0 ${DESTDIR}./lib/libcrypto.so
      fi

      if [ -e lib/libssl.so.1.0.0 ];then
        cp lib/libssl.so.1.0.0 ${DESTDIR}./lib
        ln -sf ${DESTDIR}./lib/libssl.so.1.0.0 ${DESTDIR}./lib/libssl.so
      fi
    
      if [ -e lib/libz.so.1.2.8 ];then  
       cp lib/libz.so.1.2.8 ${DESTDIR}./lib                         
       ln -sf ${DESTDIR}./lib/libz.so.1.2.8 ${DESTDIR}./lib/libz.so.1     
      fi  
  else
   kill `pidof $EXE` > /dev/null 2>&1
  fi
}

(strings credential_manager)> /dev/null 2>&1
res=$?
if [ $res -eq 0 ];then #strings command is supported
   count=$(strings credential_manager | grep 'openssl_' | wc -l )
   if [ $count -gt 0 ];then
    echo "ssl is statically linked."
   else
    echo "ssl is dynamically linked"
    copyLib
   fi
else #check if ldd is supported
   (ldd credential_manager)> /dev/null 2>&1
   res=$?
   if [ $res -eq 0 ];then #ldd is supported
     count=$(ldd credential_manager | grep 'libssl.so.0.0' | wc -l )
     if [ $count -gt 0 ];then
       echo "ssl is dynamically linked count"
       copyLib
     else
       echo "ssl is statically linked "
     fi
   else
    echo "strings and ldd are not supported"
    copyLib
   fi
fi
echo -n "Remember to copy the DDKG shared library (libnaudaddk_shared.so) to $DESTDIR/lib"
echo
