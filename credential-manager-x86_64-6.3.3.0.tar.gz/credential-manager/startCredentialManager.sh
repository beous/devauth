#!/bin/bash
EXE=credential_manager
CONF=../conf/credentialmanager.conf
if [ $(id -u) -ne 0 ]; then
  echo "You must be logged in as root or sudo to continue.."
  exit 1
fi
if [ $# -eq 0 ]; then
    echo "Configuration file for credential manager is not specified. Assuming ../conf/credentialmanager.conf"
else
   CONF=$1
fi
echo "Check if the $EXE is already running and terminate the old process"
killall $EXE
echo "Continuing with launch of credential manager"
LD_LIBRARY_PATH=`pwd`/../lib/:$LD_LIBRARY_PATH ./$EXE --config $CONF
