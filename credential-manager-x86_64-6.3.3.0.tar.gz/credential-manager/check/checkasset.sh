#! /bin/bash
FAILED=0
LOGNAME=`basename $0`.log
CONFIGFILE=/usr/local/deviceauthority/conf/credentialmanager.conf
EXE=/usr/local/deviceauthority/sbin/credential_manager
export LD_LIBRARY_PATH=.:$LD_LIBRARY_PATH
# Kill off anything else already running.
killall -q -u `whoami` -r ".*credential_manager.*"
# Override defaults if needed
if [ "$1" != "" ]; then
    CONFIGFILE=$1
fi
if [ "$2" != "" ]; then
    EXE=$2
fi
ASSETLOG=`grep LogFileName $CONFIGFILE | sed "s/LogFileName = //"`
rm -f $ASSETLOG
if [ ! -f $CONFIGFILE ]; then
    echo "Can't locate credential manager config file ($CONFIGFILE) please specify as 4th argument."
    exit 1
fi
if [ ! -x $EXE ]; then
    echo "Can't locate credential manager agent executable ($EXE) please specify as 5th argument."
    exit 1
fi
# Start up the proxy.
$EXE $CONFIGFILE > $LOGNAME
# Wait a while
COUNT=0
while [ `grep -c "Please contact " $ASSETLOG` -lt 1 ] && [ $COUNT -lt 30 ]; do
    sleep 1
    let COUNT=COUNT+1
done
if [ $COUNT -eq 30 ]; then
    echo "The executable doesn't seem to have started properly, here is the end of the log:"
    tail $ASSETLOG
    exit 1
fi
echo -n "Testing delivery of asset - "
# Wait a second
COUNT=0
while [ ! -f /tmp/test.cert ] && [ $COUNT -lt 30 ]; do
    sleep 1
    let COUNT=COUNT+1
done
# Now check the output
if [ `grep -c "END PKCS7" /tmp/test.cert` -eq 1 ] && [ `grep -c "END RSA PRIVATE KEY" /tmp/test.cert` -eq 1 ]; then
    echo -e "\033[0;32mPASS\033[0m"
else
    echo -e "\033[0;31mFAIL\033[0m"
    let FAILED=FAILED+1
    if [ `grep -c "No device found matching identification key" $ASSETLOG` -gt 0 ]; then
        echo "Device doesn't seem to be registered, have you registered yet?"
    elif [ `grep -c "No new assets found" $ASSETLOG` -gt 0 ]; then
        echo "No assets have been found, have you defined any?"
    elif [ `grep -Ec "Error .* connecting socket" $ASSETLOG` -gt 0 ]; then
        echo "Can't connect to the ASSET end point, is it running and/or reachable (blocked by firewall)?"
    elif [ `grep -Ec "Connect to API .* failed" $ASSETLOG` -gt 0 ]; then
        echo "Can't connect to the ASSET end point, is it reachable (blocked by firewall)?"
    elif [ `grep -c "Problem writing to file path" $ASSETLOG` -eq 0 ]; then
        echo "Asset reception failed, is the asset path writeable by this user?"
    elif [ `grep -c "Failed to process any assets" $ASSETLOG` -eq 0 ]; then
        echo "Asset reception failed, is your policy set up correctly?"
    fi
fi
killall -q -u `whoami` -2 -r ".*credential_manager.*"
exit $FAILED
